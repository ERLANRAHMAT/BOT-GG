const list_cod = (prefix) => {
return `*ZEEONE OFC さ*
				
PROSES	1-60Mnt 1X24 Jam			
OPEN	10.00-19.00			
FORMAT	ID			
				
LIST 

53CP	Rp 10,000.00
112CP	Rp 20,000.00
278CP	Rp 50,000.00
581CP	Rp 98,000.00
1.268CP	Rp 195,000.00
1.901CP	Rp 290,000.00
3.300CP	Rp 480,000.00
7.128CP	Rp 950,000.00

Untuk pay / pembayan silahkan ketik ${prefix}pay
`
	}

exports.list_cod = list_cod
 