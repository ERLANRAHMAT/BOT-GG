const list_price = (prefix) => {
return `🎮 LIST GAME :

${prefix}Pubg -> List Uc Pubg
${prefix}Ml -> List Diamond MLBB
${prefix}Ff -> List  Diamond FF
${prefix}Cod -> List Cp Codm
${prefix}Aov -> List Voucher Aov
${prefix}Sausage -> List Candy Sausage
${prefix}Lol -> List Wc Lol
${prefix}Valo -> List Vp Valorant

Untuk melihat listnya ketik ${prefix}list game 
Ex :
•> ${prefix}aov
	ㅁ Untuk melihat list Voucher Aov
`
	}

exports.list_price = list_price
 