const list_lol = (prefix) => {
return `*ZEEONE OFC さ*
				
PROSES	1-180Mnt 1X24 Jam			
OPEN	10.00-19.00			
FORMAT	ID			
				
WC LOLM				
			
125WC	Rp 18,000.00			
420WC	Rp 55,000.00			
700WC	Rp 85,000.00			
1.375WC	Rp 155,000.00			
2.400WC	Rp 250,000.00			
4,000.00WC	Rp 395,000.00			
8.150WC	Rp 785,000.00			
				
Untuk pay / pembayan silahkan ketik ${prefix}pay
`
	}

exports.list_lol = list_lol
 