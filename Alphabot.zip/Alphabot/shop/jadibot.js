const jadibut = () =>{
return`╭──「 📖  *PRICE JADIBOT*」
│
├ • *Test Jadibot [30-60m]*
│
│ ⤷ *Free* 💌
│
├ • *Permanen*
│
│ ⤷ *Harga :  25k [E-Wallet]*
│ ⤷ *Harga :  28k [Pulsa]*
│
├─ 「 💰  *PAYMENT* 」
│
│ ⤷ *Dana [Diutamakan]*
│ ⤷ *Ovo*
│ ⤷ *Gopay*
│ ⤷ *Pulsa Telkom*
│
├─ 「 👨‍💻  *RUN ON* 」
│
│ ⤷ *Heroku [Diutamakan]*
│ ⤷ *Railway* 
│
├─ 「 📝  *NOTES* 」
│
│ ⤷ _Tidak perlu termux_
│ ⤷ _Minat? Hubungi 0887435047326_
│
╰──「 *Thank's* 」
`
}
exports.jadibut = jadibut